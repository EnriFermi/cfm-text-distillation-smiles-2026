# Matched-H100 TinyStories results

All latency in the revised article was measured on one NVIDIA H100 NVL with
batch size 1, sequence length 256, FP32 model weights, five warm-up
generations, and the median of 30 synchronized repeats.  Error bars in the
figures are the 10th--90th percentile range.  The same upstream timing harness
from commit `2e21c57704ab94e131e3350ffd8286632f61a7b8` is used for every
model family.

## Canonical diffusion baseline latency

| Model / sampler | NFE | Forwards per sequence | Median latency (ms) |
|---|---:|---:|---:|
| MDLM | 16 | 17 | 127.97 |
| MDLM | 32 | 33 | 248.96 |
| MDLM | 64 | 65 | 482.93 |
| MDLM | 128 | 129 | 862.34 |
| MDLM | 256 | 257 | 1503.75 |
| BD3-LM ancestral, block 16 | 1 | 32 | 178.64 |
| BD3-LM ancestral, block 16 | 2 | 48 | 265.02 |
| BD3-LM ancestral, block 16 | 4 | 80 | 448.57 |
| BD3-LM ancestral, block 16 | 8 | 144 | 835.23 |
| BD3-LM ancestral, block 16 | 16 | 272 | 1508.32 |
| BD3-LM ancestral, block 16 | 32 | 528 | 3032.76 |

The separately measured BD3-LM first-hitting NFE-256 point is 1551.90 ms; it
is not joined to the ancestral quality curve because it is a different
sampler.

## Main cross-family result

MDLM NFE 16 (127.97 ms, MAUVE 0.9157, gen-PPL 26.99) strictly dominates the
best-MAUVE M3/BCFM point at NFE 16 (190.09 ms, MAUVE 0.7550, gen-PPL 58.13).
Thus M3 extends the CFM-only frontier, but not the global frontier over the
tested methods.

The supplementary directory also contains the exact baseline timing table,
the old-A100 versus new-H100 comparison, and a large dashboard preview.  The
35-row table used by the paper figure remains at the archive root as
`tinystories_quality_latency_by_nfe.csv`.
